#' RameauEnv_Foret2UNIMARC2
#'
#' Jeu de donnees bibliographiques.
#'
#' @format A data frame with 680 rows and 244 variables
#' @source GallicaEnv
"my_dataset"

